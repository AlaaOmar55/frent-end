function changeimg(filename) {
  let imgBig =document.querySelector("#big-img")
  imgBig.setAttribute("src" , filename)
}
const  btnplus = document.querySelector("#plus") ,
btnminus= document.querySelector('#minus') ,
valuea= document.querySelector(".al") ,
num = document.querySelector(".fr")
;



let count=1;
function as(){
    valuea.innerText=count;
}
btnplus.addEventListener("click" , _=>{
    count++;
    as();
})
btnminus.addEventListener("click",_=> {
    if(count<=1){
        count=1;
    }else{
        count--;
    }
    as();
})




const addBtns = document.querySelectorAll("#cartbtn");
let prodectsList = JSON.parse(localStorage.getItem("prudect")) || [];
// event click add prodect
addBtns.onclick = _ => {
}
for (const btn of addBtns) {
  btn.onclick = event => {
    event.preventDefault()
    colletDataProdect(btn)

  }

}

// Function Collect prodect data 
function colletDataprodect(item) {
  let prodectCard = item.parentElement.parentElement.parentElement.parentElement
  let prodectImg = prodectCard.querySelector("img").src;
  let prodectName = prodectCard.querySelector("h4").innerText;
  let prodectPrice = prodectCard.querySelector("#priceNumber").innerText;
  let prodectCount = item.previousElementSibling.value;


  let prodectIndex = prodectsList.findIndex( item =>{
    return item.name == prodectName
  })

  if (prodectIndex >= 0) {
    let oldCount = +prodectsList[prodectIndex].count
    oldCount += +prodectCount

    prodectsList[prodectIndex].count = oldCount
  } else {
    // add new 
    let prodectObject = {
      imgSrc: prodectImg,
      name: prodectName,
      count: prodectCount,
      price: prodectPrice
    }
  
    prodectsList.push(prodectObject)
  }

  localStorage.setItem("prodects", JSON.stringify(prodectsList));


  show()
}




// Function show all prodect store in loacl storage in list prodect Cart
const cartList = document.querySelector(".offcanvas-body"),
  allTotalEl = document.querySelector("#allTotal") ,
  prodectNumEl = document.querySelector(".main-header .number");

function show() {
  let sum = 0
  cartList.innerHTML = ""

  prodectsList.forEach( (prodect , ind)=> {
    sum += prodect.price  * prodect.count  
    let contentprodect =
      `
    <div class="row mb-3">
    <div class="col-3">
      <img src="${prodect.imgSrc}" alt="" class="img-fluid">
    </div>
    <div class="col">
      <h5>${prodect.name}</h5>
      <div class="d-flex gap-5">
        <div class="price">Price: <span class="text-primary fw-semibold">${prodect.price}</span> $</div>
        <div class="count">Count: <span class="text-primary fw-semibold">${prodect.count}</span></div>
      </div>
      <div class="total">Total: <span class="text-primary fw-semibold">${prodect.price * prodect.count}</span> $</div>
    </div>
    <div class="col-2">
      <button class="btn btn-outline-danger" data-id = ${ind} 
      onclick = "delprodect(${ind})">
        <i class="bi bi-trash3-fill"></i>
      </button>
    </div>
  </div>
    `
    cartList.innerHTML += contentprodect ;

  });
  allTotalEl.innerText = sum ;
  prodectNumEl.innerText = prodectsList.length;
}
show()

const delAllBtn = document.querySelector("#deleteAllprodect") ;
delAllBtn.onclick = deleteAllprodects
// Function delete all prodect list in cart
function deleteAllprodects() {
  localStorage.removeItem("prodects");
  prodectsList = []
  show();
}

// Function delete on prodect list in cart
function delprodect(index) {
  prodectsList.splice(index , 1)
  localStorage.setItem("prodects", JSON.stringify(prodectsList));
  show()

}


// Function to store prodect in local storge