const headertop=document.querySelector("#topheader"),
bottom=document.querySelector("#halaaa")
addEventListener("scroll" ,_=>{
    if (scrollY>100) {
        headertop.classList.add("activ") 
        bottom.classList.add("d-block") 
    }else{
        headertop.classList.remove('activ')
        bottom.classList.remove("d-block") 
    }
    
})
const cards = document.querySelectorAll('.secondSection .card');
cards[0].classList.add("scaleCard") 
function toggelLarge(clickedCard) {

     cards.forEach(function(card) {
      card.classList.remove('scaleCard');
    });

     clickedCard.classList.add('scaleCard');
}
